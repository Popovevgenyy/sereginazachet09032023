<?php
echo "<h1>404 page</h1>";
?>